import json, subprocess, time, struct, random, statistics as st, sys, os, math, tempfile
import numpy as np
REPS = int(sys.argv[1]) if len(sys.argv) > 1 else 5
T, DT = 40, 0.25
OFFSET = 0.5            # victim starts 0.5 s after the flooders are launched (as exp5)
FLOODERS = ["A", "B", "C"]              # every per-flooder structure below is keyed by this list
PAR = {"A": 4, "B": 2, "C": 2}          # iperf3 -P streams per flooder
STEADY = {                              # steady scenarios: flooder -> (start s, duration s), t rel. flooder launch
    "steady": {"A": (0, 27), "B": (13, 27)},                # exp23/exp29 (needs FLOODERS = ["A", "B"])
    "steady3": {"A": (0, 28), "B": (6, 28), "C": (12, 28)},  # exp30: all three active during 12-28 s
}
BURSTY = {                              # bursty scenarios: name of the STEADY scenario whose windows bound the bursts
    "burst": None,                      # exp24/exp29: bursts over the whole 0-T s run (BURST_DUR, BURST_OVERLAP)
    "burst3": "steady3",                # exp35: each flooder bursts only inside its steady3 window, same streams
}
BURST_DUR = 27          # burst: per-flooder normalisation duration of the iperf/eBPF means (exp29 A_DUR/B_DUR)
BURST_OVERLAP = (13.0, 27.0)  # burst: Jain fairness window (the exp29 OVERLAP constant)
SCENARIO = sys.argv[2] if len(sys.argv) > 2 else "steady3"  # a key of STEADY (continuous flooders) or of
                        # BURSTY (seeded on/off bursts); exp36 default steady3 (the exp34 scenario), burst3 = exp35
NF = len(FLOODERS)
BURST_ON = (3.0, 6.0)   # burst: on-burst duration drawn uniformly in this range (s)
BURST_OFF = (2.0, 5.0)  # burst: off-gap duration drawn uniformly in this range (s)
BURST_START = (0.0, 4.0)  # burst: first on-burst starts at a random offset in this range (s)
MIN_BURST = 2.0         # burst: a burst shorter than this after rounding to whole seconds is dropped (iperf3
                        # takes -t in whole seconds, -t 0 means "run forever", which would hang run(), and a
                        # 1 s burst is mostly iperf3 connection set-up)
KP, KI = 200.0, 300.0
CAP_MIN, CAP_MAX = 200.0, 70000.0
INIT_CAP_MBIT = 2000.0  # pid/ff: initial shared cap (split equally); slo: initial cap of each flooder
XDP_BURST_NS = 5000000  # token-bucket burst of xdp_limit.o (BURST_NS in xdp_limit.c, 5 ms at the cap rate),
                        # the same object and burst for every mode; only logged here, the program owns it
K_CPU = 0.93            # % host CPU per Gbit/s (from the Step 19 measurement)
VICTIM_RATE_GBIT = float(os.environ.get("VICTIM_RATE_GBIT", 18))  # victim offered rate, total over its streams
                        # (exp33/exp34: 18 Gbit/s, was 25; reference, slo_ok threshold and all victim floors follow it)
SLO_FRAC = 0.95         # slo_ok_fraction threshold (all modes): SLO_FRAC * reference rate
SLO_FLOORS = (95,)      # slo controller floors, % of the reference rate (one config each)
MD, AI_MBIT = 0.7, 500.0   # slo: cut factor; additive increase per tick for a sending flooder
SLO_CONSEC = 2          # slo: cut only after this many consecutive ticks below the floor
HOLDOFF = 1.0           # s, slo: no further cut for this long after a cut
SEND_MBIT = 100.0       # a flooder counts as "sending" above this rate
SMOOTH = 1.0            # s, victim/flooder rate smoothing window for the slo controller
HOLT_ALPHA, HOLT_BETA = 0.5, 0.3   # dfs: Holt level / trend smoothing of each flooder's offered rate
DFS_ACTIVE_MBIT = 50.0  # dfs: a flooder whose forecast demand is below this is inactive (gets CAP_MIN)
DFS_FLOOR = 95          # dfs: victim guard floor, % of the per-repeat reference (as slo 95)
DFS_CUT, DFS_RECOVER = 0.8, 0.05   # dfs: budget x0.8 per tick below the floor, else +5% of the ff budget
DFS2_TARGET = 75.0       # dfs2: CPU target % for the ff feed-forward budget (same target as the ff 75 config)
DFS2_WARMUP = 5.0        # s, dfs2: victim guard disabled for the first this many seconds of the run
DFS2_VS_TAU = 3.0        # s, dfs2: EMA time constant of the smoothed 1 s victim rate v_s
DFS2_VATT_TAU = 5.0      # s, dfs2: EMA time constant of the attainable-rate estimate v_att
DFS2_VATT_INIT = 0.98    # dfs2: v_att initialised to this fraction of the per-repeat reference (rate-limited
                         # victim should nearly reach its offered rate)
DFS3_VS_TAU = 1.5        # s, dfs3: EMA time constant of the smoothed 1 s victim rate v_s
DFS3_KI_DOWN = 3.0       # dfs3: integral gain of the smooth victim guard when below target (per s, x ffb)
DFS3_UP_RATE = 0.05      # dfs3: budget increase when at/above target, fraction of ffb per second
DFS4 = {}                # dfs4: param string -> (slack %, warm, minshare), parsed once in main()
ROT = {}                 # rot: param string -> (total Gbit/s, rotation period s), parsed once in main()
PIDROT = {}              # pidrot: param string -> (host CPU target %, rotation period s), parsed once in main()
PIDROTF = {}             # pidrotf: param string -> (host CPU target %, rotation period s), parsed once in main()
VFROT = {}               # vfrot: param string -> (beta, add Gbit/s per s, rotation period s, thresh), parsed once in main()
VFROT_VS_TAU = 0.5       # s, vfrot: EMA time constant of the smoothed 1 s victim rate v
VFROT_THRESH = 0.98      # vfrot: default violation threshold (3-part param): v < this x the per-repeat reference
VFROT_HOLD = 1.0         # s, vfrot: no budget increase for this long after a violation tick
VFROT_CUT_HOLD = 1.0     # s, vfrot: no further cut for this long after a cut (the 1 s victim window lags recovery)
DFS5 = {}                # dfs5: param string -> (slack %, rotation period s), parsed once in main()
DFS5_WARM = 0.3          # dfs5: warm-start budget, fraction of ffb (as dfs4 "3_0.3_0.4")
LQR = {}                 # lqr: param string -> (host CPU target %, R weight multiplier, gain K 1x2), set in main()
LQR_TAU = 0.5            # s, lqr plant time constant: y(k+1) = a*y(k) + b*u(k), a = exp(-DT/LQR_TAU),
                         # b = K_CPU*(1-a) (steady-state gain K_CPU, the same constant as pid/ff)
LQR_Q = (1.0, 1.0)       # lqr: state weights Q = diag(q_e, q_d)
LQR_R = 0.5              # lqr: input weight on du (Gbit/s); R = LQR_R * RWT
REF_RUNS, REF_T = 2, 10   # victim-only reference, measured at the start of EVERY repeat
PAUSE = 8
COOLDOWN = 45           # s, extra cool-down pause between repeats (thermal), on top of PAUSE
SESSION_REPEATS = 1     # repeats per session; a long rest follows each session except the last
SESSION_REST_S = 600    # s, thermal rest between sessions, on top of COOLDOWN
HOST = "10.10.0.1"
GUESTS = {"V": ("tenant1", "10.10.0.11", 5201),   # victim
          "A": ("tenant2", "10.10.0.12", 5202),   # flooder A
          "B": ("tenant3", "10.10.0.13", 5203),   # flooder B
          "C": ("tenant4", "10.10.0.14", 5204)}   # flooder C
HERE = os.path.dirname(os.path.abspath(__file__))
OBJ = os.path.join(HERE, "xdp_limit.o")
CSV = os.path.join(HERE, "results_dyn36.csv")
TS_CSV = os.path.join(HERE, "ts_dyn36.csv")
REF_FILE = os.path.join(HERE, "ref_victim36.txt")
LOG = os.path.join(HERE, "exp36.log")   # written by run36.sh (stdout redirect), checked in main()
# exp36: 7 configs -> 15 slots/repeat (alone interleaved); order of definition, shuffled per repeat in main()
# static: param = per-flooder cap in Mbit/s, set once at the start of the slot, no feedback
CONFIGS = [("static", "3500"), ("static", "4500"), ("static", "5500"), ("static", "6500"),
           ("lqr", "79_4"), ("lqr", "85_4"), ("vfrot", "0.8_1_2_0.94")]
HEADER = ("rep,slot,mode,param,victim_mean_gbps,victim_p5_gbps,slo_ok_fraction,"
          + "".join(f"flooder{g}_iperf_gbps,flooder{g}_ebpf_gbps," for g in FLOODERS)
          + "jain_fairness,cpu_mean,cpu_max,ref_gbps")
TS_HEADER = ("rep,slot,mode,param,t,victim_gbps_1s,"
             + "".join(f"cap{g}_mbit," for g in FLOODERS) + "".join(f"rate{g}_gbps," for g in FLOODERS)
             + "v_att,budget_mbit")

IF = {}           # "V" and each flooder -> {"dev", "prog", "cfg", "cnt"} (map ids, never names)
last_cap = {}     # cfg map id -> last bytes/s written

def sudo(args):
    return subprocess.run(["sudo", "-n"] + args, capture_output=True, text=True, check=True).stdout

# ---------- interfaces and eBPF maps, all addressed by id ----------

def vnet(dom):
    # names change after guest restarts, so always ask libvirt; '-' means the guest is not running
    rows = [l.split() for l in sudo(["virsh", "domiflist", dom]).splitlines()[2:] if l.strip()]
    rows = [r for r in rows if r[0] != "-"]
    if len(rows) != 1:
        raise SystemExit(f"{dom}: expected exactly one active interface in virsh domiflist, got {rows}")
    return rows[0][0]

def xdp_prog(dev):
    for blk in json.loads(sudo(["bpftool", "-j", "net", "show", "dev", dev])):
        for x in blk.get("xdp", []):
            if x.get("devname") != dev:
                continue
            att = x.get("multi_attachments", [x])
            if len(att) != 1:
                raise SystemExit(f"{dev}: {len(att)} XDP programs attached, expected one")
            return att[0]["id"], att[0].get("mode")
    return None, None

def attach(dev, cap_mbit):
    pid, mode = xdp_prog(dev)
    if pid is None:
        sudo(["ip", "link", "set", "dev", dev, "xdpgeneric", "obj", OBJ, "sec", "xdp"])
        pid, mode = xdp_prog(dev)
        how = "attached"
    else:
        how = "reusing already attached"
    prog = json.loads(sudo(["bpftool", "-j", "prog", "show", "id", str(pid)]))
    if prog.get("name") != "xdp_limit" or mode != "generic":
        raise SystemExit(f"{dev}: XDP prog {pid} ({prog.get('name')}, mode {mode}) is not xdp_limit "
                         f"in generic mode; detach it yourself, then rerun")
    maps = {}
    for m in prog.get("map_ids", []):
        maps[json.loads(sudo(["bpftool", "-j", "map", "show", "id", str(m)]))["name"]] = m
    if "cfg" not in maps or "cnt" not in maps:
        raise SystemExit(f"{dev}: prog {pid} has maps {maps}, expected cfg and cnt")
    d = {"dev": dev, "prog": pid, "cfg": maps["cfg"], "cnt": maps["cnt"]}
    set_cap(d, cap_mbit)
    print(f"{dev}: {how} xdp_limit prog id {pid}, cfg map id {d['cfg']}, cnt map id {d['cnt']}", flush=True)
    return d

def counters(d):
    out = sudo(["bpftool", "-j", "map", "dump", "id", str(d["cnt"])])
    c = {}
    for e in json.loads(out):
        f = e.get("formatted", e); v = f["value"]
        c[f["key"]] = sum(v) if isinstance(v, list) else v
    return c

def set_cap(d, mbps):
    # 0 = unlimited; skip the bpftool call if this map already holds the value
    b = int(mbps * 1e6 / 8)
    if last_cap.get(d["cfg"]) == b:
        return
    h = [f"{x:02x}" for x in struct.pack("<Q", b)]
    sudo(["bpftool", "map", "update", "id", str(d["cfg"]), "key", "0", "0", "0", "0", "value", "hex"] + h)
    last_cap[d["cfg"]] = b

def cpu():
    f = list(map(int, open("/proc/stat").readline().split()[1:]))
    return sum(f), f[3] + f[4]

# ---------- helpers on (t, cumulative passed bytes) histories ----------

def cum_at(h, t):
    # linear interpolation of the cumulative byte counter, clamped to the sampled range
    if t <= h[0][0]: return h[0][1]
    if t >= h[-1][0]: return h[-1][1]
    for (ta, ba), (tb, bb) in zip(h, h[1:]):
        if ta <= t <= tb:
            return ba + (bb - ba) * (t - ta) / max(1e-9, tb - ta)

def rate_mbit(h, t1, t2):
    return (cum_at(h, t2) - cum_at(h, t1)) * 8 / 1e6 / max(1e-9, t2 - t1)

def waterfill(budget, demand):
    # max-min fair split of budget over demand {g: Mbit/s}; any budget left once every demand is
    # met is shared equally, so the allocations always sum to the whole budget
    alloc, left, rest = {}, budget, sorted(demand, key=demand.get)
    while rest and demand[rest[0]] <= left / len(rest):
        g = rest.pop(0); alloc[g] = demand[g]; left -= demand[g]
    for g in rest:
        alloc[g] = left / len(rest)
    if not rest and alloc:
        for g in alloc: alloc[g] += left / len(alloc)
    return alloc

def parse_dfs4(param):
    # "SLACK_WARM_MINSHARE", e.g. "3_0.5_0.4": slack 3 %, warm start 0.5 x ffb, min share 0.4 x budget
    parts = param.split("_")
    try:
        if len(parts) != 3: raise ValueError
        slack, warm, minshare = (float(x) for x in parts)
    except ValueError:
        raise SystemExit(f"dfs4 param {param!r} is malformed: expected SLACK_WARM_MINSHARE, e.g. 3_0.5_0.4")
    if not (0 <= slack < 100 and 0 < warm <= 1 and 0 <= minshare <= 1):
        raise SystemExit(f"dfs4 param {param!r} out of range: need 0 <= SLACK < 100, 0 < WARM <= 1, "
                         f"0 <= MINSHARE <= 1")
    return slack, warm, minshare

def parse_rot(param):
    # "TOTAL_T", e.g. "16_2": TOTAL = total flooder budget 16 Gbit/s, T = rotation period 2 s
    parts = param.split("_")
    try:
        if len(parts) != 2: raise ValueError
        total, rot_t = (float(x) for x in parts)
    except ValueError:
        raise SystemExit(f"rot param {param!r} is malformed: expected TOTAL_T, e.g. 16_2")
    if not (total > 0 and rot_t > 0):
        raise SystemExit(f"rot param {param!r} out of range: need TOTAL > 0 and T > 0")
    return total, rot_t

def parse_pidrot(param):
    # "TARGET_T", e.g. "86_3": TARGET = host CPU target %, T = rotation period s
    parts = param.split("_")
    try:
        if len(parts) != 2: raise ValueError
        target, rot_t = (float(x) for x in parts)
    except ValueError:
        raise SystemExit(f"pidrot param {param!r} is malformed: expected TARGET_T, e.g. 86_3")
    if not (0 < target <= 100 and rot_t > 0):
        raise SystemExit(f"pidrot param {param!r} out of range: need 0 < TARGET <= 100 and T > 0")
    return target, rot_t

def parse_pidrotf(param):
    # "TARGET_T", e.g. "87_3": same format as pidrot (host CPU target %, rotation period s)
    parts = param.split("_")
    try:
        if len(parts) != 2: raise ValueError
        target, rot_t = (float(x) for x in parts)
    except ValueError:
        raise SystemExit(f"pidrotf param {param!r} is malformed: expected TARGET_T, e.g. 87_3")
    if not (0 < target <= 100 and rot_t > 0):
        raise SystemExit(f"pidrotf param {param!r} out of range: need 0 < TARGET <= 100 and T > 0")
    return target, rot_t

def parse_vfrot(param):
    # "BETA_ADD_T", e.g. "0.8_1_3": cut factor 0.8, additive increase 1 Gbit/s per s, rotation period 3 s,
    # threshold VFROT_THRESH; or "BETA_ADD_T_THRESH", e.g. "0.8_1_3_0.96": same with threshold 0.96
    parts = param.split("_")
    try:
        if len(parts) not in (3, 4): raise ValueError
        beta, add, rot_t = (float(x) for x in parts[:3])
        thresh = float(parts[3]) if len(parts) == 4 else VFROT_THRESH
    except ValueError:
        raise SystemExit(f"vfrot param {param!r} is malformed: expected BETA_ADD_T or BETA_ADD_T_THRESH, "
                         f"e.g. 0.8_1_3 or 0.8_1_3_0.96")
    if not (0 < beta < 1 and add > 0 and rot_t > 0 and 0.85 <= thresh <= 1.0):
        raise SystemExit(f"vfrot param {param!r} out of range: need 0 < BETA < 1, ADD > 0, T > 0 "
                         f"and 0.85 <= THRESH <= 1.0")
    return beta, add, rot_t, thresh

def parse_dfs5(param):
    # "SLACK_T", e.g. "3_5": slack 3 %, rotation period 5 s
    parts = param.split("_")
    try:
        if len(parts) != 2: raise ValueError
        slack, rot_t = (float(x) for x in parts)
    except ValueError:
        raise SystemExit(f"dfs5 param {param!r} is malformed: expected SLACK_T, e.g. 3_5")
    if not (0 <= slack < 100 and rot_t > 0):
        raise SystemExit(f"dfs5 param {param!r} out of range: need 0 <= SLACK < 100 and T > 0")
    return slack, rot_t

def parse_lqr(param):
    # "TARGET" or "TARGET_RWT", e.g. "86" or "86_4": host CPU reference %, multiplier on the input weight R
    parts = param.split("_")
    try:
        if len(parts) not in (1, 2): raise ValueError
        target = float(parts[0])
        rwt = float(parts[1]) if len(parts) == 2 else 1.0
    except ValueError:
        raise SystemExit(f"lqr param {param!r} is malformed: expected TARGET or TARGET_RWT, e.g. 86 or 86_4")
    if not (70 <= target <= 95 and 0.05 <= rwt <= 20):
        raise SystemExit(f"lqr param {param!r} out of range: need 70 <= TARGET <= 95 and 0.05 <= RWT <= 20")
    return target, rwt

def lqr_plant(gain_scale=1.0):
    # incremental model on x = [e, d] (e = y - target, d = e(k) - e(k-1)), input du (Gbit/s):
    # e(k+1) = e(k) + a*d(k) + b*du(k), d(k+1) = a*d(k) + b*du(k); gain_scale scales the plant gain
    a = math.exp(-DT / LQR_TAU)
    b = gain_scale * K_CPU * (1.0 - a)
    return np.array([[1.0, a], [0.0, a]]), np.array([[b], [b]]), a, b

def lqr_gain(rwt, tol=1e-12, max_iter=100000):
    # discrete LQR gain K (1x2) by plain Riccati iteration on the nominal plant
    A, B, _, _ = lqr_plant()
    Q, R = np.diag(LQR_Q), np.array([[LQR_R * rwt]])
    P = Q.copy()
    for _ in range(max_iter):
        Pn = Q + A.T @ P @ A - A.T @ P @ B @ np.linalg.solve(R + B.T @ P @ B, B.T @ P @ A)
        done = np.max(np.abs(Pn - P)) <= tol * max(1.0, np.max(np.abs(Pn)))
        P = Pn
        if done:
            return np.linalg.solve(R + B.T @ P @ B, B.T @ P @ A)
    raise SystemExit(f"lqr: Riccati iteration did not converge (RWT {rwt})")

def lqr_report(param, rwt, K):
    # a, b, K, closed-loop eigenvalues of A - BK, and stability with the plant gain scaled by 0.33 ... 3
    A, B, a, b = lqr_plant()
    eig = np.linalg.eigvals(A - B @ K)
    lines = [f"LQR {param}: a={a:.6f} b={b:.6f} (%/Gbit per tick) Q=diag{LQR_Q} R={LQR_R * rwt:g} "
             f"K=[{K[0, 0]:.6f}, {K[0, 1]:.6f}] eig(A-BK)=[{', '.join(f'{z:.4f}' for z in eig)}] "
             f"|eig|max={max(abs(eig)):.4f}"]
    for s in (0.33, 0.5, 2.0, 3.0):
        As, Bs, _, _ = lqr_plant(s)
        es = np.linalg.eigvals(As - Bs @ K)
        lines.append(f"LQR {param}: plant gain x{s:g}: eig=[{', '.join(f'{z:.4f}' for z in es)}] "
                     f"|eig|max={max(abs(es)):.4f} stable {'yes' if max(abs(es)) < 1 else 'no'}")
    return lines

def active_flooders(offered, prev_off):
    # active-flooder detection (rot/pidrot/pidrotf/vfrot): offered (passed + dropped) rate over this
    # tick >= DFS_ACTIVE_MBIT; returned in FLOODERS order
    return [g for g in FLOODERS
            if (offered[g][-1][1] - prev_off[g][1]) * 8 / 1e6
               / max(1e-3, offered[g][-1][0] - prev_off[g][0]) >= DFS_ACTIVE_MBIT]

def high_cap(budget, n_act):
    # cap of the holder: every other active flooder keeps CAP_MIN, so the holder gets
    # budget - (n_act - 1) * CAP_MIN; a single active flooder gets budget - CAP_MIN (as exp29)
    return max(CAP_MIN, budget - max(1, n_act - 1) * CAP_MIN)

def next_after(h, cands):
    # round-robin successor of h among cands, in FLOODERS order (h None or absent -> first after its slot)
    if h is None:
        return cands[0]
    i = FLOODERS.index(h)
    for g in FLOODERS[i + 1:] + FLOODERS[:i + 1]:
        if g in cands:
            return g

def hold_caps(act, budget, elapsed, rot_t, caps, state, pick):
    # one active flooder (the holder) gets high_cap, every other flooder CAP_MIN; the holder is
    # re-decided by pick(act, holder) when it is not active (immediately) or when it has held for
    # rot_t s (re-decision instants every rot_t s, so a voluntary hand-over is never faster than
    # rot_t); with no flooder active, keep the last caps
    if not act:
        return caps
    h = state["holder"]
    if h not in act or elapsed - state["since"] >= rot_t:
        state["holder"], state["since"] = pick(act, h), elapsed
    on = high_cap(budget, len(act))
    return [on if g == state["holder"] else CAP_MIN for g in FLOODERS]

def rot_caps(act, budget, elapsed, rot_t, caps, state):
    # rot/pidrot/dfs5: round-robin over the ACTIVE flooders (the first active flooder first)
    return hold_caps(act, budget, elapsed, rot_t, caps, state, lambda a, h: next_after(h, a))

def pidrotf_caps(act, budget, elapsed, rot_t, caps, delivered, state):
    # pidrotf/vfrot: the high cap goes to the active flooder with the LOWEST cumulative delivered
    # traffic; ties go to a flooder that is not the current holder (the next one round-robin)
    def pick(a, h):
        low = min(delivered[g] for g in a)
        tied = [g for g in a if delivered[g] == low]
        others = [g for g in tied if g != h]
        return next_after(h, others) if others else h
    return hold_caps(act, budget, elapsed, rot_t, caps, state, pick)

def pf_update(delivered, passed, act, pf_all):
    # pidrotf/vfrot: add this tick's passed bytes per flooder, then zero the counters on the first tick
    # on which ALL flooders are active (so they span only that overlap window); returns the new pf_all
    for g in FLOODERS:
        delivered[g] += passed[g]
    all_on = len(act) == NF
    if all_on and not pf_all:
        for g in FLOODERS:
            delivered[g] = 0.0
    return all_on

def act_windows():
    # flooder -> (start s, duration s) activity window of SCENARIO (burst3: the steady3 windows, inside which
    # the flooder bursts); None for "burst" (bursts anywhere in 0-T s)
    return STEADY[SCENARIO] if SCENARIO in STEADY else (STEADY[BURSTY[SCENARIO]] if BURSTY[SCENARIO] else None)

def flooder_dur(g):
    # normalisation duration of flooder g's iperf/eBPF means (burst3: its whole window, off gaps included)
    w = act_windows()
    return w[g][1] if w else BURST_DUR

def overlap():
    # window in which all flooders are active (Jain fairness), t relative to the flooder launch
    w = act_windows()
    if w is None:
        return BURST_OVERLAP
    return (float(max(w[g][0] for g in FLOODERS)), float(min(w[g][0] + w[g][1] for g in FLOODERS)))

def minshare_fill(budget, demand, minshare):
    # dfs4: with >= 2 active flooders each gets at least minshare * budget (scaled down so the floors sum
    # to at most the budget); the remaining budget is water-filled over the demand above that floor
    if len(demand) < 2:
        return waterfill(budget, demand)
    floor = min(minshare * budget, budget / len(demand))
    extra = waterfill(budget - floor * len(demand), {g: max(0.0, d - floor) for g, d in demand.items()})
    return {g: floor + extra[g] for g in demand}

def jain(xs):
    s, q = sum(xs), sum(x * x for x in xs)
    return s * s / (len(xs) * q) if q > 0 else float("nan")

def p5(xs):
    if len(xs) < 2: return xs[0] if xs else float("nan")
    return st.quantiles(xs, n=20, method="inclusive")[0]

def iperf_sum(f, secs=None):
    f.seek(0)
    try:
        s = json.loads(f.read())["end"]["sum_received"]
        return s["bytes"] * 8 / 1e9 / secs if secs else s["bits_per_second"] / 1e9
    except Exception:
        return float("nan")

def ssh(guest, cmd, out):
    return subprocess.Popen(["ssh", f"alpine@{GUESTS[guest][1]}", cmd], stdout=out, text=True)

def iperf_cmd(guest, secs, par=1, delay=0, rate_gbit=0):
    pre = f"sleep {delay}; " if delay else ""
    p = f" -P {par}" if par > 1 else ""
    # -b is the per-stream target bitrate; iperf3 applies it to each -P stream, so the total
    # offered rate is split equally over the streams (rate_gbit / par per stream)
    b = f" -b {rate_gbit / par:g}G" if rate_gbit else ""
    return f"{pre}iperf3 -c {HOST} -p {GUESTS[guest][2]} -t {secs}{p}{b} -J"

def burst_seed(rep, idx):
    # seed of the private random.Random of (repeat, flooder index); never touches the global seed-7 shuffle
    return 1000 * rep + idx

def burst_schedule(rep, idx, win=None):
    # burst: seeded on/off sequence of (start, on_duration) pairs inside the window; the schedule
    # depends only on (rep, flooder index), so it is identical for every config within a repeat (paired)
    # and each flooder (idx = position in FLOODERS) is drawn independently
    # win = (start s, duration s): bursts only inside [start, start + duration] (burst3); None = [0, T] (burst)
    # exp35: the continuous draw is unchanged (same random numbers, same order); each burst's start and end are
    # then rounded half-up to whole seconds, since iperf3 -t runs whole seconds only, so the returned (and logged)
    # schedule is what iperf3 runs; drawn gaps are >= 2 s, so rounded bursts stay >= 1 s apart; the rounded
    # times are clamped to the whole seconds inside the window
    w0, w1 = (0.0, float(T)) if win is None else (float(win[0]), float(win[0] + win[1]))
    rng = random.Random(burst_seed(rep, idx))
    sched, t = [], w0 + rng.uniform(*BURST_START)
    while t < w1:
        on = min(rng.uniform(*BURST_ON), w1 - t)   # clip the last burst so it stays inside the window
        s, e = max(math.ceil(w0), math.floor(t + 0.5)), min(math.floor(w1), math.floor(t + on + 0.5))
        if e - s < MIN_BURST:
            break                                  # only a clipped last burst can round below MIN_BURST
        sched.append((s, e - s))
        t += on + rng.uniform(*BURST_OFF)
    return sched

def burst_cmd(guest, sched, par):
    # burst: one iperf3 -t <on> client per on-burst, chained in a single remote shell so each starts at
    # its scheduled time (a leading sleep covers the gap since the previous burst ended); same -P streams
    p = f" -P {par}" if par > 1 else ""
    parts, prev_end = [], 0.0
    for start, on in sched:
        gap = start - prev_end
        pre = f"sleep {gap:g}; " if gap > 0 else ""
        parts.append(f"{pre}iperf3 -c {HOST} -p {GUESTS[guest][2]} -t {on:g}{p} -J")
        prev_end = start + on
    return "; ".join(parts)

# ---------- setup ----------

def check_servers():
    # the host iperf3 servers are started by hand; abort if any of them is not listening
    out = subprocess.run(["ss", "-ltnH"], capture_output=True, text=True).stdout
    missing = [GUESTS[g][2] for g in ["V"] + FLOODERS
               if not any(l.split()[3].endswith(f":{GUESTS[g][2]}") for l in out.splitlines() if len(l.split()) > 3)]
    if missing:
        raise SystemExit("no iperf3 server listening on host port(s) " + ", ".join(map(str, missing))
                         + "; start them first, e.g. " + "; ".join(f"iperf3 -s -D -p {p}" for p in missing))
    print("iperf3 servers listening on ports " + ", ".join(str(GUESTS[g][2]) for g in ["V"] + FLOODERS), flush=True)

def reference(rep, procs):
    # victim alone, flooder caps unlimited, eBPF bytes on the victim vnet over the 10 s run;
    # also measure the mean host CPU during the victim-alone runs -> base_cpu for this repeat
    for g in FLOODERS:
        set_cap(IF[g], 0)   # undo the caps left by the previous repeat's last run
    ebpf, ip, cpus = [], [], []
    for i in range(REF_RUNS):
        out = tempfile.TemporaryFile("w+")
        c0 = counters(IF["V"])[2]
        pt0, pi0 = cpu()
        p = ssh("V", iperf_cmd("V", REF_T, rate_gbit=VICTIM_RATE_GBIT), out); procs.append(p); p.wait()
        pt1, pi1 = cpu()
        c1 = counters(IF["V"])[2]
        busy = 100.0 * (1 - (pi1 - pi0) / max(1, (pt1 - pt0)))
        cpus.append(busy)
        ebpf.append((c1 - c0) * 8 / 1e9 / REF_T); ip.append(iperf_sum(out)); out.close()
        print(f"rep {rep} ref run {i + 1}: victim alone {ebpf[-1]:.2f} Gbit/s (eBPF), {ip[-1]:.2f} Gbit/s (iperf3), "
              f"host CPU {busy:.1f}%", flush=True)
        time.sleep(PAUSE)
    ref = st.median(ebpf)
    base_cpu = st.mean(cpus)
    if math.isnan(ref) or ref <= 0:
        raise SystemExit(f"reference measurement failed (rep {rep})")
    new = not os.path.exists(REF_FILE) or os.path.getsize(REF_FILE) == 0
    with open(REF_FILE, "a") as f:
        if new:
            f.write("# rep, time, ref_gbps (median eBPF), base_cpu (mean host %), eBPF runs, iperf3 runs; "
                    f"victim alone, {REF_RUNS} x {REF_T} s at VICTIM_RATE_GBIT={VICTIM_RATE_GBIT} Gbit/s "
                    f"at the start of each repeat\n")
        f.write(f"{rep}, {time.strftime('%Y-%m-%d %H:%M:%S')}, {ref:.3f}, {base_cpu:.1f}, "
                f"{' '.join(f'{x:.3f}' for x in ebpf)}, {' '.join(f'{x:.3f}' for x in ip)}\n")
        f.flush(); os.fsync(f.fileno())
    return ref, base_cpu

# ---------- one run ----------

def run(mode, param, ref, base_cpu, procs, scheds=None):
    ref_mbit = ref * 1000.0
    floor = (float(param) if mode == "slo" else DFS_FLOOR) / 100.0 * ref_mbit if mode in ("slo", "dfs") else None
    shared = INIT_CAP_MBIT
    if mode == "static":
        # exp36: param in Mbit/s (was Gbit/s); the same cap on every flooder, written below by set_cap before
        # any flooder starts and never again during the run (static is not in the per-tick set_cap list)
        caps = [float(param)] * NF
    elif mode[:6] == "stasym" and mode[6:] in FLOODERS:
        # stasymX: param = total flooder budget (Gbit/s); X gets all but CAP_MIN per other flooder,
        # every other flooder gets CAP_MIN
        caps = [float(param) * 1000.0 - (NF - 1) * CAP_MIN if g == mode[6:] else CAP_MIN for g in FLOODERS]
    elif mode == "rot":
        # rot: open-loop; the first flooder is "on" until the first tick decides, as if it were alone
        caps = [high_cap(ROT[param][0] * 1000.0, 1) if g == FLOODERS[0] else CAP_MIN for g in FLOODERS]
    elif mode in ("pidrot", "pidrotf", "vfrot"):
        # pidrot/pidrotf/vfrot: budget B starts at 10000 Mbit/s, allocated by rotation; first flooder on
        caps = [high_cap(10000.0, 1) if g == FLOODERS[0] else CAP_MIN for g in FLOODERS]
    elif mode in ("pid", "lqr", "lqrf", "ff", "dfs", "dfs2", "dfs2np", "dfs3", "dfs3np", "dfs4", "dfs5"):
        caps = [shared / NF] * NF
    elif mode == "slo":
        caps = [INIT_CAP_MBIT] * NF
    else:
        caps = [CAP_MAX] * NF
    target = float(param) if mode in ("pid", "ff", "dfs") else None
    holt = {}                    # dfs: flooder -> [level, trend] of the offered rate, Mbit/s
    budget = None                # dfs: guarded budget, Mbit/s
    v_s = None                   # dfs2: EMA-smoothed 1 s victim rate, Mbit/s
    v_att = DFS2_VATT_INIT * ref_mbit   # dfs2: attainable victim rate estimate, Mbit/s
    delivered = {g: 0.0 for g in FLOODERS}  # pidrotf: passed (delivered) bytes per flooder, current overlap window
    pf_all = False                          # pidrotf: were all flooders active on the previous tick
    pf_state = {"holder": None, "since": None}  # rot/pidrot/pidrotf/vfrot/dfs5: high-cap holder, when decided
    vf_block = float("-inf")                # vfrot: budget increases blocked while tnow < vf_block
    vf_cutblock = float("-inf")             # vfrot: budget cuts blocked while tnow < vf_cutblock
    lq_e1 = None                            # lqr: previous tick's CPU error e (None -> d = 0 at the first tick)
    lq_cpu = []                             # lqrf: last <=5 raw host CPU samples, for the CPU pre-filter
    # caps first, then the eBPF baseline, then the flooders: no flooder byte can precede the baseline
    for g, c in zip(FLOODERS, caps): set_cap(IF[g], c)
    if mode == "static":
        print(f"static {param}: cap set once for the whole run on " + ", ".join(
            f"{g} {IF[g]['dev']} (cfg map id {IF[g]['cfg']}) {last_cap[IF[g]['cfg']] * 8 / 1e6:g} Mbit/s"
            for g in FLOODERS), flush=True)
    hist = {g: [] for g in IF}
    offered = {g: [] for g in IF}   # (t, cumulative passed + dropped bytes), same counter read as hist
    def sample():
        for g in IF:
            c = counters(IF[g]); tn = time.monotonic()
            hist[g].append((tn, c[2])); offered[g].append((tn, c[2] + c[3]))
    sample()
    # temp files instead of pipes so large -J output can never block ssh/iperf3 mid-run
    fo = {g: tempfile.TemporaryFile("w+") for g in FLOODERS}
    vo = tempfile.TemporaryFile("w+")
    alone = mode == "alone"   # victim only, no flooders; same timeline as the other modes
    t0 = time.monotonic()
    if alone:
        fp = {}
    elif SCENARIO in BURSTY:
        fp = {g: ssh(g, burst_cmd(g, scheds[g], PAR[g]), fo[g]) for g in FLOODERS}
    else:
        # steady scenarios: one delayed (sleep) iperf3 client per flooder
        fp = {g: ssh(g, iperf_cmd(g, STEADY[SCENARIO][g][1], PAR[g], STEADY[SCENARIO][g][0]), fo[g])
              for g in FLOODERS}
    time.sleep(max(0.0, t0 + OFFSET - time.monotonic()))
    pv = ssh("V", iperf_cmd("V", T, rate_gbit=VICTIM_RATE_GBIT), vo)
    procs += list(fp.values()) + [pv]
    pt, pi = cpu(); cpus = []; e1 = 0.0; base = None; vfirst = None
    below = 0; last_cut = None   # slo: consecutive ticks below the floor, tick index of the last cut
    hold_ticks = round(HOLDOFF / DT)
    ts = []                      # one row per tick for ts_dyn36.csv
    k = 1
    while pv.poll() is None and time.monotonic() < t0 + OFFSET + T + 30:
        time.sleep(max(0.0, t0 + OFFSET + k * DT - time.monotonic())); k += 1
        prev = {g: hist[g][-1] for g in IF}
        prev_off = {g: offered[g][-1] for g in IF}
        sample(); tnow = hist["V"][-1][0]; t, i = cpu()
        busy = 100.0 * (1 - (i - pi) / max(1, (t - pt))); pt, pi = t, i
        cpus.append(busy)
        if vfirst is None and hist["V"][-1][1] > hist["V"][0][1]:
            vfirst = tnow   # first sample after victim bytes started flowing
        # flooder rates over the real elapsed time between counter reads, not the nominal DT
        tick = {g: (hist[g][-1][1] - prev[g][1]) * 8 / 1e6 / max(1e-3, hist[g][-1][0] - prev[g][0]) for g in IF}
        dt = max(1e-3, tnow - prev["V"][0])
        if mode == "pid":
            e = target - busy
            shared += KP * (e - e1) + KI * dt * e
            shared = max(CAP_MIN, min(CAP_MAX, shared)); e1 = e
            caps = [shared / NF] * NF
        elif mode in ("lqr", "lqrf"):
            # same host CPU measure (busy, this tick), tick DT, start budget INIT_CAP_MBIT, equal split and
            # clamp [CAP_MIN, CAP_MAX] as pid; only the control law differs: du = -K x, x = [e, d],
            # e = cpu_eff - target, d = e(k) - e(k-1)
            # (d = 0 at the first tick); du in Gbit/s; the clamped budget is kept (anti-windup, no extra state)
            target, _, K = LQR[param]
            if mode == "lqrf":
                # lqrf: lqr with a pre-filter on the CPU measurement only, as in the published LQR paper
                # (median filter + predictive blend); the LQR error/difference state below uses this
                # effective CPU instead of the raw busy %
                lq_cpu.append(busy); del lq_cpu[:-5]                      # keep the last 5 raw CPU samples
                smoothed = st.median(lq_cpu) if len(lq_cpu) >= 3 else lq_cpu[-1]
                predicted = 2.0 * lq_cpu[-1] - lq_cpu[-2] if len(lq_cpu) >= 2 else smoothed
                cpu_eff = 0.7 * smoothed + 0.3 * predicted
            else:
                cpu_eff = busy
            e = cpu_eff - target
            d = 0.0 if lq_e1 is None else e - lq_e1; lq_e1 = e
            du = -float((K @ np.array([e, d]))[0])
            shared = max(CAP_MIN, min(CAP_MAX, shared + 1000.0 * du))
            budget = shared
            caps = [shared / NF] * NF
        elif mode == "ff":
            # feed-forward budget from the measured per-repeat victim-alone CPU (base_cpu): the headroom
            # (target - base_cpu) in CPU %, converted to a shared flooder rate via K_CPU
            shared = max(CAP_MIN, min(CAP_MAX, (target - base_cpu) / K_CPU * 1000.0))
            caps = [shared / NF] * NF
        elif mode == "dfs":
            # (1) budget: the ff feedforward budget, same base estimate and K_CPU
            b = max(0.0, busy - K_CPU * sum(tick[g] for g in FLOODERS) / 1000.0)
            base = b if base is None else 0.5 * base + 0.5 * b
            ffb = max(CAP_MIN, min(CAP_MAX, (target - base) / K_CPU * 1000.0))
            # (4) victim guard on the 1 s victim rate, only once that window lies inside the victim's run
            if budget is None:
                budget = ffb
            elif vfirst is not None and tnow - vfirst >= SMOOTH and rate_mbit(hist["V"], tnow - SMOOTH, tnow) < floor:
                budget *= DFS_CUT
            else:
                budget += DFS_RECOVER * ffb
            budget = max(CAP_MIN, min(ffb, budget))
            # (2) demand: offered (passed + dropped) rate this tick, Holt one-tick-ahead forecast
            fc = {}
            for g in FLOODERS:
                x = (offered[g][-1][1] - prev_off[g][1]) * 8 / 1e6 / max(1e-3, offered[g][-1][0] - prev_off[g][0])
                if g not in holt:
                    holt[g] = [x, 0.0]
                else:
                    lv, tr = holt[g]
                    nlv = HOLT_ALPHA * x + (1 - HOLT_ALPHA) * (lv + tr)
                    holt[g] = [nlv, HOLT_BETA * (nlv - lv) + (1 - HOLT_BETA) * tr]
                fc[g] = max(0.0, holt[g][0] + holt[g][1])
            # (3) inactive flooders get CAP_MIN, the rest of the budget is water-filled over the active ones
            act = {g: d for g, d in fc.items() if d >= DFS_ACTIVE_MBIT}
            alloc = waterfill(budget, act)
            caps = [max(CAP_MIN, min(CAP_MAX, alloc.get(g, CAP_MIN))) for g in FLOODERS]
        elif mode in ("dfs2", "dfs2np"):
            # dfs2np: identical to dfs2 except the forecast is the current offered rate (no Holt trend)
            use_holt = mode == "dfs2"
            # (1) budget base: the ff feed-forward budget from the measured per-repeat base_cpu (same
            # headroom formula and K_CPU as the ff config), not an online CPU estimate
            ffb = max(CAP_MIN, min(CAP_MAX, (DFS2_TARGET - base_cpu) / K_CPU * 1000.0))
            # (2) demand: offered (passed + dropped) rate this tick, Holt one-tick-ahead forecast
            #     (dfs2np: the measured offered rate itself, no trend term)
            fc = {}
            for g in FLOODERS:
                x = (offered[g][-1][1] - prev_off[g][1]) * 8 / 1e6 / max(1e-3, offered[g][-1][0] - prev_off[g][0])
                if not use_holt:
                    fc[g] = max(0.0, x)
                    continue
                if g not in holt:
                    holt[g] = [x, 0.0]
                else:
                    lv, tr = holt[g]
                    nlv = HOLT_ALPHA * x + (1 - HOLT_ALPHA) * (lv + tr)
                    holt[g] = [nlv, HOLT_BETA * (nlv - lv) + (1 - HOLT_BETA) * tr]
                fc[g] = max(0.0, holt[g][0] + holt[g][1])
            # modified victim guard (the ONLY change from dfs)
            # (a) EMA-smooth the 1 s eBPF victim rate (time constant DFS2_VS_TAU) -> v_s, every tick
            v1s = (rate_mbit(hist["V"], tnow - SMOOTH, tnow)
                   if vfirst is not None and tnow - vfirst >= SMOOTH else 0.0)
            av = 1.0 - math.exp(-dt / DFS2_VS_TAU)
            v_s = v1s if v_s is None else av * v1s + (1.0 - av) * v_s
            if budget is None:
                budget = ffb
            if tnow - t0 < DFS2_WARMUP:
                # (b) guard disabled for the first DFS2_WARMUP s: budget stays at the ff budget
                budget = ffb
            else:
                # (c) update v_att only when a flooder is active (forecast) and all caps near CAP_MIN;
                #     caps here are still those in effect while v_s was measured (set below this tick)
                if (any(d >= DFS_ACTIVE_MBIT for d in fc.values())
                        and all(c <= 1.5 * CAP_MIN for c in caps)):
                    aa = 1.0 - math.exp(-dt / DFS2_VATT_TAU)
                    v_att = aa * v_s + (1.0 - aa) * v_att
                # (d) adjust the budget against the slack-relaxed attainable rate
                if v_s < v_att * (1.0 - float(param) / 100.0):
                    budget = max(NF * CAP_MIN, budget * DFS_CUT)
                else:
                    budget = min(ffb, budget + DFS_RECOVER * ffb)
            # (3) inactive flooders get CAP_MIN, the rest of the budget is water-filled over the active ones
            act = {g: d for g, d in fc.items() if d >= DFS_ACTIVE_MBIT}
            alloc = waterfill(budget, act)
            caps = [max(CAP_MIN, min(CAP_MAX, alloc.get(g, CAP_MIN))) for g in FLOODERS]
        elif mode in ("dfs3", "dfs3np", "dfs4", "dfs5"):
            # identical to dfs2 EXCEPT the victim guard is a smooth controller (below) instead of the
            # dfs2 multiplicative x0.8 / +5 % guard; param is the slack in percent
            # dfs3np: identical to dfs3 except the forecast is the current offered rate (no Holt trend)
            # dfs4: identical to dfs3np except the warm-start budget and the per-flooder minimum share
            # dfs5: identical to dfs4 (warm DFS5_WARM) except rotation (as rot) replaces the allocation
            use_holt = mode == "dfs3"
            if mode == "dfs4":
                slack, warm, minshare = DFS4[param]
            elif mode == "dfs5":
                (slack, rot_t), warm, minshare = DFS5[param], DFS5_WARM, 0.0
            else:
                slack, warm, minshare = float(param), 1.0, 0.0
            # (1) budget base: the ff feed-forward budget from the measured per-repeat base_cpu (same
            # headroom formula and K_CPU as the ff config), not an online CPU estimate
            ffb = max(CAP_MIN, min(CAP_MAX, (DFS2_TARGET - base_cpu) / K_CPU * 1000.0))
            # (2) demand: offered (passed + dropped) rate this tick, Holt one-tick-ahead forecast
            #     (dfs3np: the measured offered rate itself, no trend term)
            fc = {}
            for g in FLOODERS:
                x = (offered[g][-1][1] - prev_off[g][1]) * 8 / 1e6 / max(1e-3, offered[g][-1][0] - prev_off[g][0])
                if not use_holt:
                    fc[g] = max(0.0, x)
                    continue
                if g not in holt:
                    holt[g] = [x, 0.0]
                else:
                    lv, tr = holt[g]
                    nlv = HOLT_ALPHA * x + (1 - HOLT_ALPHA) * (lv + tr)
                    holt[g] = [nlv, HOLT_BETA * (nlv - lv) + (1 - HOLT_BETA) * tr]
                fc[g] = max(0.0, holt[g][0] + holt[g][1])
            # smooth victim guard (the ONLY change from dfs2)
            # (a) EMA-smooth the 1 s eBPF victim rate (time constant DFS3_VS_TAU) -> v_s, every tick
            v1s = (rate_mbit(hist["V"], tnow - SMOOTH, tnow)
                   if vfirst is not None and tnow - vfirst >= SMOOTH else 0.0)
            av = 1.0 - math.exp(-dt / DFS3_VS_TAU)
            v_s = v1s if v_s is None else av * v1s + (1.0 - av) * v_s
            # dfs4 warm start: initial budget warm * ffb, clamped to [NF * CAP_MIN, ffb] (dfs3: ffb)
            b0 = ffb if mode not in ("dfs4", "dfs5") else max(NF * CAP_MIN, min(ffb, warm * ffb))
            if budget is None:
                budget = b0
            if tnow - t0 < DFS2_WARMUP:
                # (b) guard disabled for the first DFS2_WARMUP s: budget stays at the initial budget
                budget = b0
            else:
                # (c) update v_att only when a flooder is active and all caps near CAP_MIN (same
                #     conditions as dfs2); caps here are still those in effect while v_s was measured
                if (any(d >= DFS_ACTIVE_MBIT for d in fc.values())
                        and all(c <= 1.5 * CAP_MIN for c in caps)):
                    aa = 1.0 - math.exp(-dt / DFS2_VATT_TAU)
                    v_att = aa * v_s + (1.0 - aa) * v_att
                # (d) smooth controller: normalised error against the slack-relaxed attainable rate;
                #     below target -> continuous decrease proportional to the shortfall, else slow rise
                e = (v_s - v_att * (1.0 - slack / 100.0)) / v_att
                if e < 0:
                    budget += dt * ffb * DFS3_KI_DOWN * e
                else:
                    budget += dt * ffb * DFS3_UP_RATE
                budget = max(NF * CAP_MIN, min(ffb, budget))
            # (3) inactive flooders get CAP_MIN, the rest of the budget is water-filled over the active ones
            #     (dfs4: after a minimum share per active flooder when at least two are active)
            #     (dfs5: rotation as rot instead, the "on" flooder gets high_cap(budget, n_active))
            act = {g: d for g, d in fc.items() if d >= DFS_ACTIVE_MBIT}
            if mode == "dfs5":
                caps = rot_caps([g for g in FLOODERS if g in act], budget, tnow - t0, rot_t, caps, pf_state)
            else:
                alloc = minshare_fill(budget, act, minshare) if mode == "dfs4" else waterfill(budget, act)
                caps = [max(CAP_MIN, min(CAP_MAX, alloc.get(g, CAP_MIN))) for g in FLOODERS]
        elif mode == "rot":
            # open-loop time-rotation, no victim feedback; total budget and period parsed in main()
            total, rot_t = ROT[param]
            budget = total * 1000.0            # logged in the time series; rot writes no v_att
            # active-flooder detection as in the dfs modes: offered (passed + dropped) rate this tick
            act = active_flooders(offered, prev_off)
            # one active: it gets budget - CAP_MIN; >= 2: the holder (round-robin over the active
            # flooders, re-decided every rot_t s) gets budget - (n_active - 1) * CAP_MIN, every other
            # flooder CAP_MIN; none: keep the last caps
            caps = rot_caps(act, budget, tnow - t0, rot_t, caps, pf_state)
        elif mode == "pidrot":
            # same PI controller on host CPU as the pid mode (same KP/KI, control tick DT, cpu measure),
            # but its output is a TOTAL flooder budget B (Mbit/s) clamped to [NF*CAP_MIN, 16000], not equal
            # caps; B is then allocated by the rot rotation logic (budget logged in the time series)
            target, rot_t = PIDROT[param]
            if budget is None:
                budget = 10000.0            # start B at 10000 Mbit/s (first tick applies the PI update)
            e = target - busy
            budget += KP * (e - e1) + KI * dt * e
            budget = max(NF * CAP_MIN, min(16000.0, budget)); e1 = e
            # active-flooder detection as in rot/dfs: offered (passed + dropped) rate this tick
            act = active_flooders(offered, prev_off)
            # allocation as rot with TOTAL = B
            caps = rot_caps(act, budget, tnow - t0, rot_t, caps, pf_state)
        elif mode in ("pidrotf", "vfrot"):
            # identical to pidrot (same PI controller on host CPU: same KP/KI, control tick DT, cpu
            # measure; same B start 10000 and clamp [NF*CAP_MIN, 16000]) EXCEPT how the holder of the
            # high cap is chosen: instead of round-robin, a cumulative per-flooder delivered-byte counter
            # is kept (the per-tick eBPF passed bytes, zeroed when all flooders become active) and, at
            # each re-decision (holder changes at most once per rot_t s), the high cap goes to the active
            # flooder with the LOWEST cumulative delivered traffic (ties -> not the current holder).
            # vfrot: identical to pidrotf EXCEPT B is not set by the host-CPU PI controller (CPU is only
            # logged): v = EMA (tau VFROT_VS_TAU) of the 1 s eBPF victim rate; v < thresh x ref is a
            # violation -> B x beta and no increase for VFROT_HOLD s; else, unless blocked, B += add per s.
            # B holds until the 1 s window lies entirely inside the victim's run (as slo); v starts there.
            if mode == "pidrotf":
                target, rot_t = PIDROTF[param]
            else:
                beta, add, rot_t, thresh = VFROT[param]
            if budget is None:
                budget = 10000.0            # start B at 10000 Mbit/s (first tick applies the update)
            if mode == "pidrotf":
                e = target - busy
                budget += KP * (e - e1) + KI * dt * e; e1 = e
            elif vfirst is not None and tnow - vfirst >= SMOOTH:
                v1s = rate_mbit(hist["V"], tnow - SMOOTH, tnow)
                av = 1.0 - math.exp(-dt / VFROT_VS_TAU)
                v_s = v1s if v_s is None else av * v1s + (1.0 - av) * v_s
                if v_s < thresh * ref_mbit:
                    vf_block = tnow + VFROT_HOLD
                    if tnow >= vf_cutblock:   # inside the cut-block a violation neither cuts nor increases
                        budget *= beta; vf_cutblock = tnow + VFROT_CUT_HOLD
                elif tnow >= vf_block:
                    budget += add * 1000.0 * dt
            budget = max(NF * CAP_MIN, min(16000.0, budget))
            # active-flooder detection as in rot/pidrot: offered (passed + dropped) rate this tick
            act = active_flooders(offered, prev_off)
            # cumulative delivered (passed) bytes per flooder, from the per-tick eBPF passed counter
            # (hist holds passed bytes); accumulated every tick, zeroed on the first tick with all active
            pf_all = pf_update(delivered, {g: hist[g][-1][1] - prev[g][1] for g in FLOODERS}, act, pf_all)
            caps = pidrotf_caps(act, budget, tnow - t0, rot_t, caps, delivered, pf_state)
        elif mode == "slo" and vfirst is not None and tnow - vfirst >= SMOOTH:
            # act only once the 1 s window lies entirely inside the victim's run
            v = rate_mbit(hist["V"], tnow - SMOOTH, tnow)
            below = below + 1 if v < floor else 0
            if v < floor:
                # cut only after SLO_CONSEC consecutive ticks below the floor and outside the hold-off
                # (counted in ticks so timing jitter cannot shorten it); otherwise hold the caps
                if below >= SLO_CONSEC and (last_cut is None or k - last_cut >= hold_ticks):
                    caps = [c * MD for c in caps]; last_cut = k
            else:
                caps = [c + AI_MBIT if rate_mbit(hist[g], tnow - SMOOTH, tnow) > SEND_MBIT else c
                        for c, g in zip(caps, FLOODERS)]
            caps = [max(CAP_MIN, min(CAP_MAX, c)) for c in caps]
        if mode in ("pid", "lqr", "lqrf", "ff", "slo", "dfs", "dfs2", "dfs2np", "dfs3", "dfs3np", "dfs4", "dfs5", "rot", "pidrot", "pidrotf", "vfrot"):
            for g, c in zip(FLOODERS, caps): set_cap(IF[g], c)
        # t relative to flooder launch; caps as set at this tick; flooder rates over this tick
        ts.append((tnow - t0, rate_mbit(hist["V"], tnow - SMOOTH, tnow) / 1000.0,
                   *caps, *(tick[g] / 1000.0 for g in FLOODERS),
                   v_att if mode in ("dfs2", "dfs2np", "dfs3", "dfs3np", "dfs4", "dfs5") else float("nan"),
                   budget if mode in ("dfs2", "dfs2np", "dfs3", "dfs3np", "dfs4", "dfs5", "rot", "pidrot", "pidrotf", "vfrot", "lqr", "lqrf") else float("nan")))
    pv.wait()
    for p in fp.values(): p.wait()
    # end of the eBPF window: after all iperf3 sessions have stopped, same bytes iperf3 counts
    sample()
    vmean = iperf_sum(vo)
    per = []          # per flooder: iperf3 mean, eBPF mean (Gbit/s), in FLOODERS order
    for g in FLOODERS:
        if alone:
            per += [0.0, 0.0]
        else:
            per += [iperf_sum(fo[g], flooder_dur(g)),
                    (hist[g][-1][1] - hist[g][0][1]) * 8 / 1e9 / flooder_dur(g)]
    for f in list(fo.values()) + [vo]: f.close()
    # 1 s victim windows from the first sample with victim bytes; T-1 windows stay inside the run
    wins = []
    if vfirst is not None:
        wins = [rate_mbit(hist["V"], vfirst + j, vfirst + j + 1) / 1000.0 for j in range(int(T) - 1)]
    vp5 = p5(wins)
    ok = sum(w >= SLO_FRAC * ref for w in wins) / len(wins) if wins else float("nan")
    # Jain over the eBPF (passed) rates of all flooders in the window where all are active (as exp29)
    # burst3: that window is still the steady3 overlap (12-28 s) and each rate is the AVERAGE over the whole
    # window, off gaps included, so it measures fairness of the delivered volume there, not per-instant shares
    ov = overlap()
    rates = [rate_mbit(hist[g], t0 + ov[0], t0 + ov[1]) for g in FLOODERS]
    jf = float("nan") if alone else jain(rates)   # no flooders: fairness undefined
    return (vmean, vp5, ok, *per, jf,
            st.mean(cpus) if cpus else float("nan"), max(cpus) if cpus else float("nan")), ts

def ms(xs):
    xs = [x for x in xs if not math.isnan(x)]
    if not xs: return float("nan"), float("nan")
    return st.mean(xs), (st.stdev(xs) if len(xs) > 1 else 0.0)

def expected_duration(n_configs, reps):
    # per slot ~ OFFSET + T + ~2.5 s ssh/iperf3 overhead + PAUSE; per repeat the reference
    # (REF_RUNS x (REF_T + ~1 s + PAUSE)) plus (2N + 1) slots; SESSION_REST_S between repeats
    n_slots = 2 * n_configs + 1
    per_rep = REF_RUNS * (REF_T + 1 + PAUSE) + n_slots * (OFFSET + T + 2.5 + PAUSE)
    total = reps * per_rep + (reps - 1) * SESSION_REST_S
    return n_slots, per_rep, total

def main():
    random.seed(7)
    # exp36: victim offered 18 Gbit/s; 7 configs -> 15 slots/repeat (alone interleaved), ~13.4 min/repeat
    configs = list(CONFIGS)
    if SCENARIO not in list(STEADY) + list(BURSTY):
        raise SystemExit(f"SCENARIO {SCENARIO!r} unknown: expected one of {list(STEADY) + list(BURSTY)}")
    if act_windows() is not None and sorted(act_windows()) != sorted(FLOODERS):
        raise SystemExit(f"SCENARIO {SCENARIO!r} defines flooders {sorted(act_windows())}, FLOODERS is {FLOODERS}")
    if any(g not in GUESTS or g not in PAR for g in FLOODERS):
        raise SystemExit(f"every flooder in {FLOODERS} needs a GUESTS and a PAR entry")
    for m, p in configs:
        if m in ("pid", "ff", "dfs", "slo", "static"):
            try:
                x = float(p)
            except ValueError:
                raise SystemExit(f"{m} param {p!r} is malformed: expected a number")
            if not (CAP_MIN <= x <= CAP_MAX if m == "static" else 0 < x <= 100):   # static: Mbit/s
                raise SystemExit(f"{m} param {p!r} out of range")
        elif m == "dfs4":
            DFS4[p] = parse_dfs4(p)
        elif m == "dfs5":
            DFS5[p] = parse_dfs5(p)
        elif m == "rot":
            ROT[p] = parse_rot(p)
        elif m == "pidrot":
            PIDROT[p] = parse_pidrot(p)
        elif m == "pidrotf":
            PIDROTF[p] = parse_pidrotf(p)
        elif m == "vfrot":
            VFROT[p] = parse_vfrot(p)
        elif m in ("lqr", "lqrf"):
            # lqrf: same param format/limits and the same gain as lqr (only the CPU measurement is filtered)
            target, rwt = parse_lqr(p)
            LQR[p] = (target, rwt, lqr_gain(rwt))
    ALONE = ("alone", "na")   # victim-only control, run before the first config and after every config
    res = {c: [] for c in configs + [ALONE]}
    # never append to or overwrite earlier output: refuse to start if any output file already exists
    # (exp36.log is allowed only when it is this process's own stdout, i.e. just created by run36.sh)
    try:
        own_log = os.path.exists(LOG) and os.path.samestat(os.fstat(sys.stdout.fileno()), os.stat(LOG))
    except (OSError, ValueError, AttributeError):
        own_log = False
    existing = [f for f in (CSV, TS_CSV, REF_FILE) if os.path.exists(f)]
    if os.path.exists(LOG) and not own_log:
        existing.append(LOG)
    if existing:
        raise SystemExit("REFUSING TO START: output file(s) already exist: " + ", ".join(existing)
                         + " -- move or delete them first (exp36 never appends)")
    try:
        sudo(["true"])
    except subprocess.CalledProcessError:
        raise SystemExit("sudo needs a password: run 'sudo -v' first (run36.sh does this)")
    if not os.path.exists(OBJ):
        raise SystemExit(f"{OBJ} not found")
    new = not os.path.exists(CSV) or os.path.getsize(CSV) == 0
    if not new and open(CSV).readline().strip() != HEADER:
        raise SystemExit(f"{CSV} exists with a different header; not appending to it")
    ts_new = not os.path.exists(TS_CSV) or os.path.getsize(TS_CSV) == 0
    if not ts_new and open(TS_CSV).readline().strip() != TS_HEADER:
        raise SystemExit(f"{TS_CSV} exists with a different header; not appending to it")
    check_servers()
    print(f"SCENARIO {SCENARIO}" + (": " + ", ".join(
              f"flooder {g} ({GUESTS[g][0]}) t={STEADY[SCENARIO][g][0]}-{sum(STEADY[SCENARIO][g])} s ({PAR[g]} streams)"
              for g in FLOODERS) + f", all active {overlap()[0]:g}-{overlap()[1]:g} s, no bursts"
          if SCENARIO in STEADY else
          f": seeded on/off bursts per repeat and flooder (on {BURST_ON[0]:g}-{BURST_ON[1]:g} s, off "
          f"{BURST_OFF[0]:g}-{BURST_OFF[1]:g} s, first start {BURST_START[0]:g}-{BURST_START[1]:g} s"
          + (" after the window start; " + ", ".join(
              f"{g} ({GUESTS[g][0]}) window {act_windows()[g][0]}-{sum(act_windows()[g])} s" for g in FLOODERS)
             + f", all windows open {overlap()[0]:g}-{overlap()[1]:g} s (Jain window)" if act_windows() else "")
          + f"; last burst clipped at the window end; start/end rounded to whole seconds (iperf3 -t), "
          f"bursts < {MIN_BURST:g} s dropped; "
          + ", ".join(f"{g} {PAR[g]} streams" for g in FLOODERS) + "; same schedule for all configs in a repeat, "
          f"seed 1000*rep + flooder index (private random.Random); iperf columns nan, eBPF columns valid)"), flush=True)
    print("CONFIGS: " + ", ".join(f"{m} {p}" + (f" (thresh {VFROT[p][3]:.2f})" if m == "vfrot" else "")
                                  + (" (Mbit/s per flooder)" if m == "static" else "") for m, p in configs), flush=True)
    print(f"TOKEN BUCKET: all modes use the same xdp_limit.o on every flooder interface, burst "
          f"{XDP_BURST_NS / 1e6:g} ms at the cap rate; victim interface never limited (counter only)", flush=True)
    print(f"VICTIM: offers {VICTIM_RATE_GBIT:g} Gbit/s (total over its streams; reference, slo_ok threshold "
          f"{SLO_FRAC * 100:g}% of the reference and victim floors all measured/derived at this rate)", flush=True)
    lqr_modes = {}   # param -> modes using it (lqr/lqrf share a param, gain and plant; lqrf adds a CPU filter)
    for m, p in configs:
        if m in ("lqr", "lqrf"):
            lqr_modes.setdefault(p, []).append(m)
    for p, (target, rwt, K) in LQR.items():
        print(f"LQR {p} ({'/'.join(dict.fromkeys(lqr_modes.get(p, ['lqr'])))}): target {target:g}% host CPU, "
              f"RWT {rwt:g}, budget clamp [{CAP_MIN:g}, {CAP_MAX:g}] Mbit/s (as pid), start "
              f"{INIT_CAP_MBIT:g} Mbit/s (equal split)", flush=True)
        for line in lqr_report(p, rwt, K):
            print(line, flush=True)
    # expected duration (see expected_duration): 2N + 1 = 15 slots/repeat for the 7 CONFIGS
    n_slots, per_rep, total = expected_duration(len(configs), REPS)
    print(f"EXPECTED DURATION: {n_slots} slots/repeat, ~{per_rep / 60:.1f} min/repeat, {REPS} repeats + "
          f"{REPS - 1} x {SESSION_REST_S} s rest ~ {total / 3600:.2f} h", flush=True)
    procs = []
    refs = []         # reference used in each repeat
    base_cpus = []    # measured victim-alone host CPU mean used in each repeat
    csv = open(CSV, "a")
    tsf = open(TS_CSV, "a")
    try:
        for g in ["V"] + FLOODERS:
            IF[g] = attach(vnet(GUESTS[g][0]), 0)   # all unlimited; victim stays 0 (counter only)
        for m, p in configs:
            if m == "static":
                burst_mb = float(p) / 8 * XDP_BURST_NS / 1e9   # MB the 5 ms burst allows at this cap
                print(f"STATIC {p}: per-flooder cap {float(p):g} Mbit/s (burst {burst_mb:.2f} MB), set once at the "
                      "start of each slot on " + ", ".join(
                          f"{g} = {GUESTS[g][0]} {IF[g]['dev']} (cfg map id {IF[g]['cfg']})" for g in FLOODERS)
                      + f"; victim {GUESTS['V'][0]} {IF['V']['dev']} unlimited", flush=True)
        if new:
            csv.write(HEADER + "\n"); csv.flush()
        if ts_new:
            tsf.write(TS_HEADER + "\n"); tsf.flush()
        print(f"{REPS} repeats x ({len(configs)} configs + {len(configs) + 1} interleaved alone runs), "
              f"writing {CSV} and {TS_CSV}; reference re-measured at the start of every repeat, victim "
              f"offered {VICTIM_RATE_GBIT} Gbit/s, {SESSION_REST_S} s rest after every repeat except the "
              f"last (the {COOLDOWN} s cool-down applies only to a repeat not preceded by a rest)", flush=True)
        rested = False
        for rep in range(1, REPS + 1):
            if rep > 1 and not rested:
                print(f"cool-down {COOLDOWN} s before repeat {rep}", flush=True)
                time.sleep(COOLDOWN)
            rested = False
            # reference first (consumes no random numbers), then this repeat's shuffled order
            ref, base_cpu = reference(rep, procs); refs.append(ref); base_cpus.append(base_cpu)
            print(f"REFERENCE rep {rep}: victim rate {ref:.3f} Gbit/s (median of {REF_RUNS} x {REF_T} s, eBPF), "
                  f"base_cpu {base_cpu:.1f}% (mean host CPU, victim alone), "
                  f"slo_ok threshold {SLO_FRAC * ref:.3f} Gbit/s, dfs victim floor "
                  f"{DFS_FLOOR}% = {DFS_FLOOR / 100 * ref:.3f} Gbit/s, saved to {REF_FILE}", flush=True)
            # burst: draw the per-flooder on/off schedule once per repeat (same for every config within
            # the repeat so configs stay paired); log it, then reuse it for all flooder runs this repeat
            # (burst3: bounded to each flooder's steady3 window; private seeded generators, so the global
            # seed-7 shuffle below draws exactly the same numbers as without bursts)
            scheds = None
            if SCENARIO in BURSTY:
                w = act_windows()
                scheds = {g: burst_schedule(rep, i, w[g] if w else None) for i, g in enumerate(FLOODERS)}
                print(f"rep {rep} BURST SEEDS: " + ", ".join(f"{g}={burst_seed(rep, i)}" for i, g in enumerate(FLOODERS)),
                      flush=True)
                for i, g in enumerate(FLOODERS):
                    bursts = ", ".join(f"[{s:d}-{s + d:d}]" for s, d in scheds[g])
                    print(f"rep {rep} burst schedule flooder {g} ({PAR[g]} streams, seed {burst_seed(rep, i)}, "
                          f"t rel. flooder launch): {bursts}", flush=True)
            print("rep slot mode           param v_mean  v_p5  slo_ok "
                  + "".join(f"{g}_iperf {g}_ebpf " for g in FLOODERS) + " jain cpu_mean cpu_max", flush=True)
            order = configs[:]; random.shuffle(order)
            seq = [ALONE] + [x for c in order for x in (c, ALONE)]   # alone, c1, alone, ..., cN, alone
            for slot, (m, p) in enumerate(seq):
                r, ts = run(m, p, ref, base_cpu, procs, scheds); res[(m, p)].append(r)
                # r = (v_mean, v_p5, slo_ok, (iperf, ebpf) per flooder..., jain, cpu_mean, cpu_max)
                fl, jf, cm, cx = r[3:3 + 2 * NF], r[3 + 2 * NF], r[4 + 2 * NF], r[5 + 2 * NF]
                csv.write(f"{rep},{slot},{m},{p},{r[0]:.3f},{r[1]:.3f},{r[2]:.3f},"
                          + "".join(f"{x:.3f}," for x in fl)
                          + f"{jf:.4f},{cm:.2f},{cx:.2f},{ref:.3f}\n"); csv.flush()
                os.fsync(csv.fileno())
                # ts row = (t, v, cap per flooder..., rate per flooder..., v_att, budget)
                tsf.write("".join(f"{rep},{slot},{m},{p},{row[0]:.3f},{row[1]:.3f},"
                                  + "".join(f"{c:.1f}," for c in row[2:2 + NF])
                                  + "".join(f"{x:.3f}," for x in row[2 + NF:2 + 2 * NF])
                                  + f"{row[-2]:.3f},{row[-1]:.1f}\n" for row in ts)); tsf.flush()
                os.fsync(tsf.fileno())
                print(f"{rep:3d} {slot:4d} {m:7s} {p:>12s} {r[0]:6.2f} {r[1]:5.2f} {r[2]:6.2f} "
                      + "".join(f"{a:7.2f} {b:6.2f} " for a, b in zip(fl[0::2], fl[1::2]))
                      + f"{jf:5.3f} {cm:8.1f} {cx:7.1f}", flush=True)
                time.sleep(PAUSE)
            if rep % SESSION_REPEATS == 0 and rep < REPS:
                print(f"session rest {SESSION_REST_S} s", flush=True)
                time.sleep(SESSION_REST_S)
                rested = True   # the rest replaces the next repeat's cool-down (no double thermal wait)
    finally:
        for p in procs:
            if p.poll() is None: p.terminate()
        for d in IF.values():
            last_cap.pop(d["cfg"], None)   # force the write
            try:
                set_cap(d, 0)
            except Exception as ex:
                print(f"WARNING: could not reset cap on {d['dev']} (cfg map id {d['cfg']}): {ex}", flush=True)
        csv.close(); tsf.close()

    names = (["v_mean", "v_p5", "slo_ok"] + [f"{g}_{k}" for g in FLOODERS for k in ("iperf", "ebpf")]
             + ["jain", "cpu_mean", "cpu_max"])
    print("\nREFERENCES per repeat (Gbit/s): " + ", ".join(f"rep {i + 1} = {r:.3f} (base_cpu {b:.1f}%)"
                                                           for i, (r, b) in enumerate(zip(refs, base_cpus))))
    print(f"\nSUMMARY (mean +- sd over {REPS} repeats; alone pooled over all {len(configs) + 1} slots per repeat)")
    print("mode           param    n " + " ".join(f"{n:>15s}" for n in names))
    for c in configs + [ALONE]:
        cols = [ms([r[j] for r in res[c]]) for j in range(len(names))]
        print(f"{c[0]:7s} {c[1]:>12s} {len(res[c]):4d} " + " ".join(f"{a:6.2f} +- {b:5.2f}" for a, b in cols))

if __name__ == "__main__":
    main()
